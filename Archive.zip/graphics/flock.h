#ifndef FLOCK_HEADER
#define FLOCK_HEADER

#include "bird.h"

typedef struct
{
    Bird * birds;
    Boid * boids;
    int numBirds;
} Flock;

void Flock_init(Flock * flock, int numBirds);
void Flock_draw(Flock * flock);
Bird * Flock_getBird(Flock * flock, int index);
void Flock_step(Flock * flock);
void Flock_setWeights(Flock * flock, float seperationWeight, float alignWeight, float cohesionWeight);

#endif