#ifndef GRAPHICS_CONSTANTS
#define GRAPHICS_CONSTANTS

#define MAX_X 200
#define MAX_Y 200
#define MAX_Z 200
#define MIN_X -200
#define MIN_Y 0
#define MIN_Z -200

#endif